##################################
#README: This script conducts random resampling of specimens, followed by repetition of all steps of the analysis following the fitting of efourier() harmonics. This serves as a sentitivity test for the inclusion or exclusion of specimens from the analysis.

##bootstrap analysis
source("fourier.R")#first run the LDA with all specimens

reps<-1000 #how often to repeat the resampling
specs<-nrow(lda__$posterior) #number of specimens for which to save results
boot_p<-array(NA, dim=c(reps,3,specs)) #empty array

for(i in 1:reps){
#rerun analysis with subsample, write out resulting estimate for xxxx specimens to boot_p[i,]
#########
sample(seq(1,nrow(outl_fourier$coe),1), nrow(outl_fourier$coe), replace=TRUE)->bootrns#randomly sample row numbers for the efourier results

outl_fourier$coe[bootrns,]->boot_fourier#save efourier results with sampled row numbers

nrow(boot_fourier)+nrow(input_fourier$coe)->l#length of all data when concatenated
nrow(input_fourier$coe)->l_#length of data to be classified
l-l_->l__#ending point for training data
l__+1->l___#starting point for input

prcomp(as.matrix(boot_fourier))->pca#PCA

predict(pca, as.matrix(input_fourier$coe))->inppca#predict principal components for input data

scale(rbind(pca$x, inppca))->inppca_scaled#combined data scaling for pc scores of training and input

inppca_scaled[l___:l,]->input_scaled
inppca_scaled[1:l__,]->pca_scaled

MASS::lda(fac[bootrns]~pca_scaled[,1:7], prior=c(1,1,1)/3)->lda#linear discriminant analysis on scaled PC scores

predict(lda, data.frame(pca_scaled)[,1:7])->lda_#base data LD score estimation

input_scaled->pca_scaled

predict(lda, data.frame(pca_scaled[,1:7]))->lda__#input data LD score and probability estimation

#save data for specimens
for(j in 1:specs){#for each specimen, write the posterior probabilities to the array

if(length(lda__$posterior[j,colnames(lda__$posterior)=="pter"])==1){
lda__$posterior[j,colnames(lda__$posterior)=="pter"]->boot_p[i,1,j]
}else{NA->boot_p[i,1,j]}

if(length(lda__$posterior[j,colnames(lda__$posterior)=="saur"])==1){
lda__$posterior[j,colnames(lda__$posterior)=="saur"]->boot_p[i,2,j]
}else{NA->boot_p[i,2,j]}

if(length(lda__$posterior[j,colnames(lda__$posterior)=="ther"])==1){
lda__$posterior[j,colnames(lda__$posterior)=="ther"]->boot_p[i,3,j]
}else{NA->boot_p[i,3,j]}

}#end saving results


}#end of all for-loops

colnames(boot_p)<-c("pter", "saur","ther")


if(1==1){

##extract classifications
#specimen P91001
boot_p_class_1<-numeric(nrow(boot_p))
for(i in 1:nrow(boot_p)){
boot_p_class_1[i]<-which(boot_p[i,1:3,1]==max(boot_p[i,1:3,1], na.rm=T))
}
gsub(1,c("pterosaur"),boot_p_class_1)->boot_p_class_1
gsub(2,c("sauropodomorph"),boot_p_class_1)->boot_p_class_1
gsub(3,c("theropod"),boot_p_class_1)->boot_p_class_1


#specimen P91002
boot_p_class_2<-numeric(nrow(boot_p))
for(i in 1:nrow(boot_p)){
boot_p_class_2[i]<-which(boot_p[i,1:3,2]==max(boot_p[i,1:3,2], na.rm=T))
}
gsub(1,c("pterosaur"),boot_p_class_2)->boot_p_class_2
gsub(2,c("sauropodomorph"),boot_p_class_2)->boot_p_class_2
gsub(3,c("theropod"),boot_p_class_2)->boot_p_class_2


#summarize results:
##specimen P91001
data.frame(p_pter=signif(boot_p[,1,1],3),p_saur=signif(boot_p[,2,1],3),p_ther=signif(boot_p[,3,1],3),classification=boot_p_class_1)->boot_p_class_1

print(paste(rownames(lda__$posterior)[1],"P91001"))

#save
table(boot_p_class_1$classification)->classif1
if(is.na(classif1["pterosaur"])){
c(pterosaur=0,classif1)->classif1
}

##save results as data.frame

as.data.frame(rbind(apply(boot_p[,1:3,1], 2, mean, na.rm=T),classif1,classif1/reps))->boot_P91001
rbind(boot_P91001,results$posterior[1,])->boot_P91001

rownames(boot_P91001)<-c("mean posterior probabilities","classifications","share of classifications","full model")
colnames(boot_P91001)<-c("Pterosauria","Sauropodomorpha","Theropoda")

print(boot_P91001)


##specimen P91002
data.frame(p_pter=signif(boot_p[,1,2],3),p_saur=signif(boot_p[,2,2],3),p_ther=signif(boot_p[,3,2],3),classification=boot_p_class_2)->boot_p_class_2


print(paste(rownames(lda__$posterior)[2],"P91002"))

#save
table(boot_p_class_2$classification)->classif2

##save results as data.frame
as.data.frame(rbind(apply(boot_p[,1:3,2], 2, mean, na.rm=T),classif2, classif2/reps))->boot_P91002
rbind(boot_P91002,results$posterior[2,])->boot_P91002

rownames(boot_P91002)<-c("mean posterior probabilities","classifications","share of classifications","full model")
colnames(boot_P91002)<-c("Pterosauria","Sauropodomorpha","Theropoda")

print(boot_P91002)

write.table(boot_P91002,"boot_P91002.txt")
write.table(boot_P91001,"boot_P91001.txt")

}
#####################
