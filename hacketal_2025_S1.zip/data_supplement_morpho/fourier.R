##################################
#README: This script conducts the elliptical fourier transformation, PCA and LDA on the fourier coefficients and classification of the two specimens of interest.


set.seed(42)
#load libraries
library(Momocs)
library(viridis)
library(geomorph)
library(MASS)
#load custom plotting functions:
source("col_asign.R")
source("modstack.R")

##uncomment following line if "input_fourier.R" has already been run
#source("input_fourier.R") #produces a coo object named 'outl' with all shapes, shapes that are unidentified are denoted by outl$fac$types=='xxxx'

##plot shapes

panel(outl, cols=col_asign(outl$fac$types, FUN=viridis))#plot shapes as panel

modstack(outl)#plot shapes as stack

#sort training from testing datasets
filter(outl,types=="xxxx")->unknown # uncategorized data, to be identified by the analysis

filter(outl,types!="xxxx")->ol # categorized data, to be used for training the algorithm

##run efourier (training)
#calibrate_reconstructions_efourier(ol, id=1, range=1:16) #visually determine how many harmonics are needed

efourier(ol, nb.h=12, norm=F)->outl_fourier #elliptical fourier analysis using 12 harmonics

outl_fourier$fac$types<-factor(outl_fourier$fac[outl_fourier$fac$types!="xxxx",]$types)
outl_fourier$fac$species<-factor(outl_fourier$fac[outl_fourier$fac$types!="xxxx",]$species)#remove uncatecorized factor levels

outl_fourier$fac$types->fac#factor for lda

##efourier on testing dataset
efourier(unknown, nb.h=12, norm=F)->input_fourier

###PCA and LDA:

nrow(outl_fourier$coe)+nrow(input_fourier$coe)->l
nrow(input_fourier$coe)->l_
l-l_->l__#ending point for training
l-l_+1->l___#starting point for input

#prcomp(as.matrix(scale(rbind(as.matrix(outl_fourier$coe),input_fourier$coe)))[1:l__,])->pca#pca on scaled data
prcomp(as.matrix(outl_fourier$coe))->pca#unscaled data

predict(pca, as.matrix(input_fourier$coe))->input_pca

scale(rbind(pca$x, input_pca))->pca_scaled#combined data scaling for pc scores


pca_scaled[l___:l,]->input_scaled
pca_scaled[1:l__,]->pca_scaled

MASS::lda(fac~pca_scaled[,1:35], prior=c(1,1,1)/3)->lda#linear discriminant analysis on scaled PC scores

predict(lda, data.frame(pca_scaled)[,1:35])->lda_#base data LD score estimation
print(table(fac,lda_$class))#print table with classification accuracy
print(mean(fac==lda_$class))


pca_scaled->pca_scaled_bkp
pca_scaled<-input_scaled

predict(lda, data.frame(pca_scaled))->lda__#input data LD score and probability estimation
print(round(lda__$posterior,3))
print(lda__$x)

lda__->results


