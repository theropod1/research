modstack<-function(coo, indices=c(1:length(coo)), col=NULL, lwd=1, lty=1, xlim=NULL, ylim=NULL, alpha=1, xlab="", ylab="", xpd=FALSE, add=FALSE, asp=1,...){
par("xpd")->oxpd
par(xpd=xpd)

if(inherits(what="Coo",outl)){
dplyr::pull(unclass(coo)$fac[,1])[indices]->fac
coo$coo[indices]->coo
}

if(is.null(col)){
col<-col_asign(fac,viridis::viridis)
}


if(add==FALSE){
##find plot limits
as.data.frame(coo[1])->c

prange<-c(min(c[,1],na.rm=T),max(c[,1],na.rm=T),min(c[,2],na.rm=T),max(c[,2],na.rm=T))

for(i in 2:length(coo)){
as.data.frame(c)->c

min(c[,1],na.rm=T)->minx
max(c[,1],na.rm=T)->maxx
min(c[,2],na.rm=T)->miny
max(c[,2],na.rm=T)->maxy

min(c(prange[1], minx))->prange[1]
max(c(prange[2], maxx))->prange[2]
min(c(prange[3], miny))->prange[3]
max(c(prange[4], maxy))->prange[4]

}
##actual plotting

if(is.null(xlim)){
prange[1:2]->xlim
}
if(is.null(ylim)){
prange[3:4]->ylim
}

plot(x=as.data.frame(coo[1])[,1],y=as.data.frame(coo[1])[,2], type="n", xlim=prange[1:2], ylim=prange[3:4],asp=asp, xlab=xlab,ylab=ylab,...)#empty plot
}

#plotting vector prep
if(length(col)<length(coo)){
rep(col, length(coo))->col
}

if(length(alpha)<length(coo)){
rep(alpha, length(coo))->alpha
}

if(length(lwd)<length(coo)){
rep(lwd, length(coo))->lwd
}

if(length(lty)<length(coo)){
rep(lty, length(coo))->lty
}


##plot polygons
for(i in 1:length(coo)){
as.data.frame(coo[i])->c
polygon(x=c[,1], y=c[,2], border=paleoDiv::add.alpha(col[i],alpha[i]), lwd=lwd[i], lty=lty[i])

}

par(xpd=oxpd)
}
