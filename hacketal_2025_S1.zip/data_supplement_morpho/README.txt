README:
This folder contains all the files and R code necessary for replicating the morphometric analysis of ungual phalanges presented in the present work.

To execute, unzip all files into a directory containing no other .jpg-files and start R in the directory.

"input_fourier.R" reads the ungual silhouettes from the jpg files and aligns the silhouettes.
"fourier.R" fits the fourier-coefficients to the silhouettes and conducts the morphometric analysis with all specimens included
"bootstrap.R" conducts a resampling sensitivity analysis to evaluate the effect of sampling on the analysis results

"modstack.R" and "col_asign.R" are custom helper functions called from within fourier.R that are only relevant for visualization purposes.

"sources.txt" contains a list of all specimens included in the training dataset, including sources

"fourier_transform.txt" contains a table of fourier coefficients after elliptical fourier transformation for all specimens in the training dataset (=the training dataset)

"fourier_transform2.txt" contains a table of fourier coefficients after elliptical fourier transformation for the two ungual specimens under study (=the testing dataset)

"outline_coo_resampled.tps" a tps file containing the aligned outline coordinates for all specimens
