##################################
#README: This script reads the ungual silhouettes, provided as .jpg-files in the same directory, saves pertinent specimen-based information, and performs procrustes alignment for the resulting outline coordinates.

#load libraries:
library(Momocs)
library(geomorph)
##readme
#script for importing jpg files with outlines, aligning using geomorph/procrustes and processing of factors
#save .jpg files in character vector ls, first 4 characters of name are type, 6-10 are species, 12 is m (manus) or p (pes), 13 is digit number
##e.g. ther_di_we_m1.jpg -> theropod, dilophosaurus wetherilli, manual digit 1

list.files()->ls#read file names
ls[grep(".jpg",ls)]->ls

list()->info#make list object for storing temporary variables, in this case claw positions and specimens
substr(ls,start=1, stop=4)->info$types
substr(ls, start=6, stop=10)->info$species
substr(ls, start=12, stop=12)->info$limb
paste0(info$limb, substr(ls, start=13, stop=13))->info$digit

import_jpg(ls)->outl_raw #import jpgs
Out(outl_raw)->outl #convert into coo-object

###factors for coo object
factor(info$types)->info$types
factor(info$species)->info$species
factor(info$limb)->info$limb
factor(info$digit)->info$digit
outl$fac<-dplyr::tibble(info$types, info$species, info$digit)
colnames(outl$fac)<-c("types","species","pos")


##alignment
coo_interpolate(outl, 1000)->outl#interpolate 1000 coordinates per outline

#procrustes alignment in geomorph with sliders
matrix(NA, 1000, 3)->sliders#make empty matrix with 1000 coordinates
for(i in 1:1000){
sliders[i,]<-c(i-1,i,i+1)}#for every line, enter the point before, semilandmark and point after (as in geomorph::define.sliders)

sliders[1,3]<-1000#define point before first point as last point
sliders[1000,3]<-1#define point after last point as first point (outline is closed)
colnames(sliders)<-c("before","slide","after")#appropriate colnames for geomorph::gpagen()

##define first point, in this case as point furthest to the right
cootemp<-array(numeric(), c(1000,2,length(outl$coo)))#make empty array
for(i in 1:length(outl$coo)){
matrix(unlist(as.array(outl$coo)[i]), ncol=2)->cootemp_

which(cootemp_[,1]==max(cootemp_[,1]))[1]->cutoff #pick point that is furthest to the right as starting point
cutof<-cutoff-1 #pick point before that that is furthest to the right as starting point

rbind(cootemp_[cutoff:nrow(cootemp_),], cootemp_[1:cutof,])->cootemp[,,i]}#rearrange matrix
#confirm positions of first point and of opposite point
for(i in 1:30){print(which(cootemp[,1,i]==max(cootemp[,1,i])))}
for(i in 1:30){print(which(cootemp[,1,i]==min(cootemp[,1,i])))}



gpagen(cootemp, curves=sliders[2:200,])->procrustes_cootemp#run gpagen
for(i in 1:30){print(which(procrustes_cootemp$coords[,1,i]==min(procrustes_cootemp$coords[,1,i])))}


#put resulting procrustes fit back in coo object, with appropriate naming
names(outl$coo)->names
Out(procrustes_cootemp$coords)$coo->outl$coo
names(outl$coo)<-names

coo_interpolate(outl, 1000)->outl

